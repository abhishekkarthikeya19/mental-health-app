
from fastapi import FastAPI
from pydantic import BaseModel
import joblib

app = FastAPI()

# Load model and vectorizer
model = joblib.load("backend/model.pkl")
vectorizer = joblib.load("backend/vectorizer.pkl")

class InputText(BaseModel):
    text: str

@app.get("/")
def home():
    return {"message": "Mental Health Predictor is running."}

@app.post("/predict/")
def predict(input_data: InputText):
    vector = vectorizer.transform([input_data.text])
    prediction = model.predict(vector)[0]
    result = "At Risk" if prediction == 1 else "No Risk"
    return {"prediction": result}
